import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../public/index.html', import.meta.url), 'utf8');
const adminMarkup = html.slice(html.indexOf('id="adminModal"'), html.indexOf('id="principalModal"'));
const principalMarkup = html.slice(html.indexOf('id="principalModal"'), html.indexOf('id="principalEditModal"'));

test('Admin tools are accessible through five menu sections instead of report footers', () => {
  const menuItems = [...adminMarkup.matchAll(/data-admin-view="([^"]+)"/g)].map((match) => match[1]);
  assert.deepEqual(menuItems, ['session-movement', 'session-changes', 'resubmission', 'date-changes', 'settings']);
  assert.match(adminMarkup, /id="adminMenuToggle"/);
  assert.match(adminMarkup, /id="adminMenuPanel"/);
  assert.match(adminMarkup, /id="adminReportBack"/);
  assert.doesNotMatch(adminMarkup, /class="admin-actions-details/);
});

test('Principal gets the matching compact layout and keeps all seven management sections', () => {
  const menuItems = [...principalMarkup.matchAll(/data-principal-view="([^"]+)"/g)].map((match) => match[1]);
  assert.deepEqual(menuItems, ['session-movement', 'session-changes', 'edit-records', 'deleted', 'resubmission', 'date-changes', 'settings']);
  for (const id of ['principalMenuToggle', 'principalMenuPanel', 'principalReportBack', 'principalReportView', 'principalSettingsView']) {
    assert.match(principalMarkup, new RegExp(`id="${id}"`));
  }
  assert.match(html, /function showPrincipalView\(view = 'report'\)[\s\S]*?panel\.hidden = key !== config/);
});

test('Mobile CSS preserves hidden views instead of forcing all Admin panels open', () => {
  assert.doesNotMatch(html, /admin-secondary-view\s*\{[^}]*display:\s*block\s*!important/i);
  assert.match(html, /#adminModal \.admin-view\[hidden\]\s*\{\s*display:\s*none\s*!important;/);
  assert.match(html, /#principalModal \.admin-view\[hidden\]\s*\{\s*display:\s*none\s*!important;/);
  assert.match(html, /function showAdminView\(view = 'report'\)[\s\S]*?panel\.hidden = key !== config/);
});

test('Admin report includes the full-register views and an explicit Grand Total row', () => {
  assert.match(adminMarkup, /id="adminReportView"/);
  assert.match(adminMarkup, /id="adminSessionMovementView"/);
  assert.match(adminMarkup, /id="adminSessionChangesView"/);
  assert.match(adminMarkup, /id="adminResubmissionView"/);
  assert.match(adminMarkup, /id="adminDateChangesView"/);
  assert.match(adminMarkup, /id="adminSettingsView"/);
  assert.match(html, /registerTotalRow\('Grand Total', allClasses/);
});
