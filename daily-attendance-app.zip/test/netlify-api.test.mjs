import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler } from '../netlify/functions/api.mjs';

function createMemoryStore() {
  const entries = new Map();
  let sequence = 0;
  return {
    async getWithMetadata(key) {
      const entry = entries.get(key);
      return entry ? { data: structuredClone(entry.data), etag: entry.etag, metadata: {} } : null;
    },
    async setJSON(key, value, options = {}) {
      const existing = entries.get(key);
      if (options.onlyIfNew && existing) return { modified: false };
      if (options.onlyIfMatch && (!existing || options.onlyIfMatch !== existing.etag)) return { modified: false };
      const etag = `"test-${++sequence}"`;
      entries.set(key, { data: structuredClone(value), etag });
      return { modified: true, etag };
    },
    async list({ prefix = '' } = {}) {
      return { blobs: [...entries.keys()].filter((key) => key.startsWith(prefix)).map((key) => ({ key, etag: entries.get(key).etag })) };
    },
  };
}

function client(handler, pinHeader = null, pin = null) {
  return async (path, { method = 'GET', body, headers = {} } = {}) => {
    const requestHeaders = new Headers(headers);
    if (pinHeader && pin) requestHeaders.set(pinHeader, pin);
    const response = await handler(new Request(`https://school.test${path}`, {
      method,
      headers: requestHeaders,
      body: body === undefined ? undefined : JSON.stringify(body),
    }));
    const payload = await response.json();
    return { status: response.status, payload };
  };
}

test('Netlify API shares submissions and protects Admin/Principal routes', async () => {
  const store = createMemoryStore();
  const handler = createHandler(() => store);
  const teacher = client(handler);
  const admin = client(handler, 'x-admin-pin', '2468');
  const principal = client(handler, 'x-principal-pin', '5678');
  const wrongPrincipal = client(handler, 'x-principal-pin', '2468');

  const config = await teacher('/api/config');
  assert.equal(config.status, 200);
  assert.equal(config.payload.classes.length, 19);
  const { today } = config.payload;
  const record = { date: today, classKey: 'IA', total: 30, present: 27, aadhaar: 25, bank: 23 };

  const submit = await teacher('/api/submit', { method: 'POST', body: record });
  assert.equal(submit.status, 201);
  assert.equal(submit.payload.record.absent, 3);
  const secondPhoneView = await teacher(`/api/records?date=${today}`);
  assert.equal(secondPhoneView.payload.records.length, 1);
  assert.equal(secondPhoneView.payload.records[0].classKey, 'IA');
  assert.equal((await teacher('/api/submit', { method: 'POST', body: record })).status, 409);

  assert.equal((await admin('/api/admin/verify', { method: 'POST', body: { pin: '2468' } })).status, 200);
  assert.equal((await principal('/api/principal/verify', { method: 'POST', body: { pin: '5678' } })).status, 200);
  assert.equal((await wrongPrincipal('/api/principal/verify', { method: 'POST', body: { pin: '2468' } })).status, 401);
  const report = await admin(`/api/admin/records?date=${today}`);
  assert.equal(report.status, 200);
  assert.equal(report.payload.records.length, 1);
  assert.equal((await admin('/api/admin/unlock', { method: 'POST', body: { date: today, classKey: 'IA' } })).status, 200);
  const resubmission = await teacher('/api/submit', { method: 'POST', body: { ...record, total: 32, present: 29, aadhaar: 27, bank: 25 } });
  assert.equal(resubmission.status, 201);
  assert.equal(resubmission.payload.record.revision, 2);

  const move = await principal('/api/principal/update-record', {
    method: 'POST', body: { date: today, classKey: 'IA', newClassKey: 'IIB', total: 31, present: 29, aadhaar: 27, bank: 25 },
  });
  assert.equal(move.status, 200);
  assert.equal(move.payload.record.classKey, 'IIB');
  assert.equal(move.payload.record.absent, 2);
  const classUpdate = await admin('/api/admin/classes', {
    method: 'POST', body: { groups: [...config.payload.groups, { key: 'VI', name: 'Class VI', short: 'VI', sections: ['A'] }] },
  });
  assert.equal(classUpdate.status, 200);
  assert.ok(classUpdate.payload.classes.some((item) => item.key === 'VIA'));

  const trash = await principal('/api/principal/delete-record', { method: 'POST', body: { date: today, classKey: 'IIB' } });
  assert.equal(trash.status, 200);
  const emptyReport = await principal(`/api/principal/records?date=${today}`);
  assert.equal(emptyReport.payload.records.length, 0);
  assert.equal(emptyReport.payload.deletedRecords.length, 1);
  const restore = await principal('/api/principal/restore-record', { method: 'POST', body: { date: today, deletedId: trash.payload.deleted.id } });
  assert.equal(restore.status, 200);
  const restored = await teacher(`/api/records?date=${today}`);
  assert.equal(restored.payload.records.length, 1);
  assert.equal(restored.payload.records[0].classKey, 'IIB');

  const newAdminPin = client(handler, 'x-admin-pin', '9753');
  const changeAdminPin = await principal('/api/principal/admin-pin', { method: 'POST', body: { newPin: '9753' } });
  assert.equal(changeAdminPin.status, 200);
  assert.equal((await admin(`/api/admin/records?date=${today}`)).status, 401);
  assert.equal((await newAdminPin(`/api/admin/records?date=${today}`)).status, 200);
  const changePrincipalPin = await principal('/api/principal/change-pin', { method: 'POST', body: { newPin: '8642' } });
  assert.equal(changePrincipalPin.status, 200);
  const newPrincipalPin = client(handler, 'x-principal-pin', '8642');
  assert.equal((await principal(`/api/principal/records?date=${today}`)).status, 401);
  assert.equal((await newPrincipalPin(`/api/principal/records?date=${today}`)).status, 200);
});

test('Netlify compare-and-swap keeps one same-class submission under concurrency', async () => {
  const store = createMemoryStore();
  const handler = createHandler(() => store);
  const teacherA = client(handler);
  const teacherB = client(handler);
  const { today } = (await teacherA('/api/config')).payload;
  const body = { date: today, classKey: 'IIA', total: 28, present: 26, aadhaar: 22, bank: 20 };
  const outcomes = await Promise.all([
    teacherA('/api/submit', { method: 'POST', body }),
    teacherB('/api/submit', { method: 'POST', body: { ...body, present: 25 } }),
  ]);
  assert.deepEqual(outcomes.map((item) => item.status).sort(), [201, 409]);
  const records = await teacherA(`/api/records?date=${today}`);
  assert.equal(records.payload.records.length, 1);
});

test('session movement totals include opening balances and recalculate after corrections, deletion, and restore', async () => {
  const store = createMemoryStore();
  const handler = createHandler(() => store);
  const teacher = client(handler);
  const admin = client(handler, 'x-admin-pin', '2468');
  const principal = client(handler, 'x-principal-pin', '5678');
  const { today } = (await teacher('/api/config')).payload;
  const dayOffset = (date, offset) => {
    const value = new Date(`${date}T00:00:00.000Z`);
    value.setUTCDate(value.getUTCDate() + offset);
    return value.toISOString().slice(0, 10);
  };
  const yesterday = dayOffset(today, -1);
  const sessionStart = dayOffset(today, -30);
  const openingSettings = {
    startDate: sessionStart,
    openingByClass: { IA: { startingTotal: 20, admission: 2, withdrawal: 1, dormant: 1 } },
  };

  const saveSettings = await admin('/api/admin/session-settings', { method: 'POST', body: openingSettings });
  assert.equal(saveSettings.status, 200);
  assert.equal(saveSettings.payload.session.startDate, sessionStart);
  assert.equal(saveSettings.payload.session.openingByClass.IA.startingTotal, 20);
  assert.equal((await principal('/api/admin/session-settings', { method: 'POST', body: openingSettings })).status, 200);

  const mismatchedStrength = await teacher('/api/submit', {
    method: 'POST', body: { date: yesterday, classKey: 'IA', baseTotal: 20, admission: 3, withdrawal: 1, dormant: 1, total: 99, present: 20, aadhaar: 19, bank: 18 },
  });
  assert.equal(mismatchedStrength.status, 400);

  const yesterdaySubmit = await teacher('/api/submit', {
    method: 'POST', body: { date: yesterday, classKey: 'IA', baseTotal: 20, admission: 3, withdrawal: 1, dormant: 1, total: 21, present: 20, aadhaar: 19, bank: 18 },
  });
  assert.equal(yesterdaySubmit.status, 201);
  assert.equal(yesterdaySubmit.payload.record.total, 21);
  assert.equal(yesterdaySubmit.payload.record.absent, 1);
  const prefilledPrevious = await teacher(`/api/previous?date=${today}&classKey=IA`);
  assert.equal(prefilledPrevious.payload.record.total, 21);

  const todaySubmit = await teacher('/api/submit', {
    method: 'POST', body: { date: today, classKey: 'IA', baseTotal: 21, admission: 2, withdrawal: 1, dormant: 0, total: 22, present: 21, aadhaar: 20, bank: 19 },
  });
  assert.equal(todaySubmit.status, 201);

  const initialReport = await admin(`/api/admin/records?date=${today}`);
  assert.deepEqual(initialReport.payload.sessionSummary.openingTotals, { admission: 2, withdrawal: 1, dormant: 1 });
  assert.deepEqual(initialReport.payload.sessionSummary.totals, { admission: 7, withdrawal: 3, dormant: 2 });
  assert.equal(initialReport.payload.sessionSummary.movements.length, 2);

  assert.equal((await admin('/api/admin/unlock', { method: 'POST', body: { date: today, classKey: 'IA' } })).status, 200);
  const correction = await teacher('/api/submit', {
    method: 'POST', body: { date: today, classKey: 'IA', baseTotal: 21, admission: 1, withdrawal: 2, dormant: 1, total: 19, present: 18, aadhaar: 17, bank: 16 },
  });
  assert.equal(correction.status, 201);
  const correctedReport = await admin(`/api/admin/records?date=${today}`);
  assert.deepEqual(correctedReport.payload.sessionSummary.totals, { admission: 6, withdrawal: 4, dormant: 3 });
  const resubmissionHistory = correctedReport.payload.sessionSummary.history.find((item) => item.action === 'resubmit');
  assert.equal(resubmissionHistory.oldRecord.admission, 2);
  assert.equal(resubmissionHistory.newRecord.admission, 1);
  assert.equal(resubmissionHistory.oldRecord.withdrawal, 1);
  assert.equal(resubmissionHistory.newRecord.withdrawal, 2);

  const moved = await principal('/api/principal/update-record', {
    method: 'POST', body: { date: today, classKey: 'IA', newClassKey: 'IIB', baseTotal: 21, admission: 2, withdrawal: 1, dormant: 1, total: 21, present: 20, aadhaar: 19, bank: 18 },
  });
  assert.equal(moved.status, 200);
  assert.equal(moved.payload.record.total, 21);
  const movedReport = await principal(`/api/principal/records?date=${today}`);
  assert.deepEqual(movedReport.payload.sessionSummary.totals, { admission: 7, withdrawal: 3, dormant: 3 });
  assert.equal(movedReport.payload.sessionSummary.movements.find((item) => item.date === today).classKey, 'IIB');

  const trash = await principal('/api/principal/delete-record', { method: 'POST', body: { date: today, classKey: 'IIB' } });
  assert.equal(trash.status, 200);
  const afterDelete = await principal(`/api/principal/records?date=${today}`);
  assert.deepEqual(afterDelete.payload.sessionSummary.totals, { admission: 5, withdrawal: 2, dormant: 2 });
  const restore = await principal('/api/principal/restore-record', { method: 'POST', body: { date: today, deletedId: trash.payload.deleted.id } });
  assert.equal(restore.status, 200);
  const afterRestore = await principal(`/api/principal/records?date=${today}`);
  assert.deepEqual(afterRestore.payload.sessionSummary.totals, { admission: 7, withdrawal: 3, dormant: 3 });
  assert.equal(afterRestore.payload.sessionSummary.movements.length, 2);

  const lightweightRefresh = await admin(`/api/admin/records?date=${today}&includeSession=false`);
  assert.equal(lightweightRefresh.status, 200);
  assert.equal(lightweightRefresh.payload.sessionSummary, null);
});
