import { randomUUID, timingSafeEqual } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const STORE_NAME = 'npv-e-block-attendance';
const SETTINGS_KEY = 'settings';
const DAY_PREFIX = 'day:';
const INITIAL_ADMIN_PIN = String(process.env.ADMIN_PIN || '2468');
const INITIAL_PRINCIPAL_PIN = String(process.env.PRINCIPAL_PIN || '5678');

const DEFAULT_GROUPS = [
  { key: 'NUR', name: 'Nursery', short: 'NUR', sections: [''] },
  { key: 'KG', name: 'K.G.', short: 'K.G.', sections: ['A', 'B'] },
  { key: 'I', name: 'Class I', short: 'I', sections: ['A', 'B', 'C'] },
  { key: 'II', name: 'Class II', short: 'II', sections: ['A', 'B', 'C'] },
  { key: 'III', name: 'Class III', short: 'III', sections: ['A', 'B', 'C'] },
  { key: 'IV', name: 'Class IV', short: 'IV', sections: ['A', 'B', 'C'] },
  { key: 'V', name: 'Class V', short: 'V', sections: ['A', 'B', 'C', 'D'] },
];

const clone = (value) => JSON.parse(JSON.stringify(value));
const recordKey = (date, classKey) => `${date}|${classKey}`;

function normalizeGroups(input) {
  if (!Array.isArray(input) || input.length < 1 || input.length > 30) return null;
  const groupKeys = new Set();
  const classKeys = new Set();
  const groups = [];
  for (const raw of input) {
    if (!raw || typeof raw !== 'object') return null;
    const key = String(raw.key || '').trim().toUpperCase();
    const name = String(raw.name || '').trim().slice(0, 40);
    const short = String(raw.short || key).trim().slice(0, 12);
    if (!/^[A-Z0-9]{1,8}$/.test(key) || !name || !short || !/^[A-Z0-9. ]{1,12}$/i.test(short) || groupKeys.has(key)) return null;
    if (!Array.isArray(raw.sections) || raw.sections.length > 12) return null;
    const sections = raw.sections.map((value) => {
      const section = String(value == null ? '' : value).trim().toUpperCase();
      return section === '-' || section === '—' || section === 'NONE' ? '' : section;
    });
    if (!sections.length) sections.push('');
    if (sections.some((section) => section !== '' && !/^[A-Z0-9]{1,4}$/.test(section))) return null;
    if (new Set(sections).size !== sections.length) return null;
    for (const section of sections) {
      const classKey = `${key}${section}`;
      if (classKeys.has(classKey)) return null;
      classKeys.add(classKey);
    }
    groupKeys.add(key);
    groups.push({ key, name, short, sections });
  }
  return groups;
}

function classesFromGroups(groups) {
  return groups.flatMap((group) => group.sections.map((section) => {
    const key = `${group.key}${section}`;
    let label;
    if (!section) label = group.short || group.key;
    else if (group.key === 'KG' || String(group.short).endsWith('.')) label = `${group.short}${section}`;
    else label = `${group.short} ${section}`;
    return { key, label, grade: group.name, groupKey: group.key, section, active: true };
  }));
}

const DEFAULT_CLASSES = classesFromGroups(DEFAULT_GROUPS);
const DEFAULT_CLASS_BY_KEY = new Map(DEFAULT_CLASSES.map((item) => [item.key, item]));

function reportClasses(groups, records) {
  const classes = classesFromGroups(groups);
  const seen = new Set(classes.map((item) => item.key));
  for (const record of records) {
    if (seen.has(record.classKey)) continue;
    const fallback = DEFAULT_CLASS_BY_KEY.get(record.classKey);
    classes.push({
      key: record.classKey,
      label: record.classLabel || fallback?.label || record.classKey,
      grade: record.grade || fallback?.grade || 'Archived class',
      groupKey: record.groupKey || fallback?.groupKey || 'ARCHIVED',
      section: record.section || fallback?.section || '',
      active: false,
    });
    seen.add(record.classKey);
  }
  const activeOrder = new Map(classesFromGroups(groups).map((item, index) => [item.key, index]));
  const oldOrder = new Map(DEFAULT_CLASSES.map((item, index) => [item.key, index]));
  return classes.sort((a, b) => {
    const aa = activeOrder.has(a.key) ? activeOrder.get(a.key) : 1000 + (oldOrder.get(a.key) ?? 999);
    const bb = activeOrder.has(b.key) ? activeOrder.get(b.key) : 1000 + (oldOrder.get(b.key) ?? 999);
    return aa - bb || a.label.localeCompare(b.label);
  });
}

function defaultSessionStartDate(today = todayIST()) {
  const [year, month] = today.split('-').map(Number);
  return `${month >= 4 ? year : year - 1}-04-01`;
}

function normalizeSessionSettings(input) {
  const startDate = validDate(input?.startDate) ? input.startDate : defaultSessionStartDate();
  const openingByClass = {};
  const raw = input?.openingByClass && typeof input.openingByClass === 'object' && !Array.isArray(input.openingByClass) ? input.openingByClass : {};
  for (const [classKey, counts] of Object.entries(raw)) {
    if (!/^[A-Z0-9]{1,12}$/i.test(classKey) || !counts || typeof counts !== 'object') continue;
    const startingRaw = counts.startingTotal;
    const startingTotal = startingRaw !== '' && startingRaw != null && Number.isInteger(Number(startingRaw)) && Number(startingRaw) >= 0 && Number(startingRaw) <= 500 ? Number(startingRaw) : null;
    openingByClass[classKey] = { startingTotal, ...Object.fromEntries(['admission', 'withdrawal', 'dormant'].map((field) => {
      const value = Number(counts[field] ?? 0);
      return [field, Number.isInteger(value) && value >= 0 && value <= 1000000 ? value : 0];
    })) };
  }
  return { startDate, openingByClass };
}

function emptySettings() {
  return { groups: clone(DEFAULT_GROUPS), pins: { admin: INITIAL_ADMIN_PIN, principal: INITIAL_PRINCIPAL_PIN }, session: normalizeSessionSettings(null) };
}

function normalizeSettings(input) {
  const defaults = emptySettings();
  if (!input || typeof input !== 'object') return defaults;
  return {
    groups: normalizeGroups(input.groups) || defaults.groups,
    session: normalizeSessionSettings(input.session),
    pins: {
      admin: validPin(input.pins?.admin) ? input.pins.admin : defaults.pins.admin,
      principal: validPin(input.pins?.principal) ? input.pins.principal : defaults.pins.principal,
    },
  };
}

function emptyDay() {
  return { records: [], history: [], deletedRecords: [], reopenAllowed: {} };
}

function normalizeDay(input) {
  if (!input || typeof input !== 'object') return emptyDay();
  return {
    records: Array.isArray(input.records) ? input.records.map(normalizeStoredRecord) : [],
    history: Array.isArray(input.history) ? input.history : [],
    deletedRecords: Array.isArray(input.deletedRecords) ? input.deletedRecords : [],
    reopenAllowed: input.reopenAllowed && typeof input.reopenAllowed === 'object' ? input.reopenAllowed : {},
  };
}

function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function todayIST() {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function validDateForSchool(date, today) {
  return validDate(date) && date <= today;
}

function validPin(pin) {
  return typeof pin === 'string' && /^\d{4,12}$/.test(pin);
}

function pinMatches(candidate, expected) {
  if (typeof candidate !== 'string' || typeof expected !== 'string') return false;
  const given = Buffer.from(candidate, 'utf8');
  const wanted = Buffer.from(expected, 'utf8');
  return given.length === wanted.length && timingSafeEqual(given, wanted);
}

function validateCounts(body) {
  const baseTotal = Number(body.baseTotal ?? body.total);
  const admission = Number(body.admission ?? 0);
  const withdrawal = Number(body.withdrawal ?? 0);
  const dormant = Number(body.dormant ?? 0);
  const total = baseTotal + admission - withdrawal - dormant;
  const present = Number(body.present);
  const aadhaar = Number(body.aadhaar);
  const bank = Number(body.bank);
  if (![baseTotal, admission, withdrawal, dormant, present, aadhaar, bank].every(Number.isInteger)) return { error: 'Enter whole-number student counts.' };
  if (baseTotal < 0 || baseTotal > 500 || admission < 0 || admission > 500 || withdrawal < 0 || withdrawal > 500 || dormant < 0 || dormant > 500) return { error: 'Starting total and daily movement counts must be between 0 and 500.' };
  if (total < 0 || total > 500) return { error: 'Current class strength must be between 0 and 500 after movements.' };
  if (body.total != null && body.total !== '' && Number(body.total) !== total) return { error: 'Current class strength does not match the movement calculation.' };
  if (present < 0 || present > total) return { error: 'Present students cannot exceed the current class strength.' };
  if (aadhaar < 0 || aadhaar > total) return { error: 'Aadhaar count cannot exceed the current class strength.' };
  if (bank < 0 || bank > total) return { error: 'Bank account count cannot exceed the current class strength.' };
  return { baseTotal, admission, withdrawal, dormant, total, present, absent: total - present, aadhaar, bank };
}

function normalizeStoredRecord(record) {
  const admission = Number.isInteger(Number(record?.admission)) ? Number(record.admission) : 0;
  const withdrawal = Number.isInteger(Number(record?.withdrawal)) ? Number(record.withdrawal) : 0;
  const dormant = Number.isInteger(Number(record?.dormant)) ? Number(record.dormant) : 0;
  const storedTotal = Number.isInteger(Number(record?.total)) ? Number(record.total) : 0;
  const baseTotal = Number.isInteger(Number(record?.baseTotal)) ? Number(record.baseTotal) : storedTotal - admission + withdrawal + dormant;
  const total = baseTotal + admission - withdrawal - dormant;
  const present = Number.isInteger(Number(record?.present)) ? Number(record.present) : 0;
  return { ...record, baseTotal, admission, withdrawal, dormant, total, present, absent: total - present };
}

function publicSessionSettings(input) {
  const session = normalizeSessionSettings(input);
  const openingByClass = {};
  for (const [classKey, counts] of Object.entries(session.openingByClass)) {
    openingByClass[classKey] = { startingTotal: counts.startingTotal };
  }
  return { startDate: session.startDate, openingByClass };
}

function sessionSummaryFromDays(settings, throughDate, days) {
  const session = normalizeSessionSettings(settings.session);
  const includeOpening = throughDate >= session.startDate;
  const openingTotals = { admission: 0, withdrawal: 0, dormant: 0 };
  if (includeOpening) for (const counts of Object.values(session.openingByClass)) {
    for (const field of Object.keys(openingTotals)) openingTotals[field] += counts[field] || 0;
  }
  const records = days.flatMap(({ date, day }) => day.records.map((record) => ({ ...record, date })))
    .filter((record) => record.date >= session.startDate && record.date <= throughDate);
  const totals = { ...openingTotals };
  for (const record of records) {
    totals.admission += record.admission || 0;
    totals.withdrawal += record.withdrawal || 0;
    totals.dormant += record.dormant || 0;
  }
  const classes = reportClasses(settings.groups, records);
  const order = new Map(classes.map((item, index) => [item.key, index]));
  const movements = records.filter((record) => record.admission || record.withdrawal || record.dormant)
    .map((record) => ({ date: record.date, classKey: record.classKey, classLabel: record.classLabel || classes.find((item) => item.key === record.classKey)?.label || record.classKey, admission: record.admission || 0, withdrawal: record.withdrawal || 0, dormant: record.dormant || 0 }))
    .sort((a, b) => b.date.localeCompare(a.date) || (order.get(a.classKey) ?? 9999) - (order.get(b.classKey) ?? 9999));
  const history = days.flatMap(({ day }) => day.history).filter((item) => item.date >= session.startDate && item.date <= throughDate)
    .sort((a, b) => String(b.editedAt || '').localeCompare(String(a.editedAt || '')));
  return { startDate: session.startDate, throughDate, openingTotals, totals, openingByClass: session.openingByClass, movements, history };
}

async function readSessionSummary(store, settings, throughDate) {
  const session = normalizeSessionSettings(settings.session);
  const { blobs = [] } = await store.list({ prefix: DAY_PREFIX });
  const dates = blobs.map((blob) => blob.key.slice(DAY_PREFIX.length))
    .filter((date) => validDate(date) && date >= session.startDate && date <= throughDate).sort();
  const days = [];
  const concurrency = 20;
  for (let start = 0; start < dates.length; start += concurrency) {
    const chunk = dates.slice(start, start + concurrency);
    const values = await Promise.all(chunk.map(async (date) => ({ date, day: normalizeDay(await readJson(store, dayKey(date))) })));
    days.push(...values);
  }
  return sessionSummaryFromDays(settings, throughDate, days);
}

function jsonResponse(status, payload) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' },
  });
}

function apiError(status, message) {
  return jsonResponse(status, { message });
}

async function parseBody(request) {
  try {
    const body = await request.json();
    return body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  } catch (_) {
    throw Object.assign(new Error('Invalid JSON body.'), { status: 400 });
  }
}

async function readJson(store, key) {
  const entry = await store.getWithMetadata(key, { type: 'json', consistency: 'strong' });
  return entry ? entry.data : null;
}

// Compare-and-swap writes prevent simultaneous phone submissions from silently overwriting one another.
async function mutateJson(store, key, initialValue, normalize, mutator) {
  for (let attempt = 0; attempt < 32; attempt += 1) {
    const entry = await store.getWithMetadata(key, { type: 'json', consistency: 'strong' });
    const current = entry ? normalize(entry.data) : initialValue();
    const draft = clone(current);
    const outcome = await mutator(draft);
    if (outcome.persist === false) return jsonResponse(outcome.status || 200, outcome.body || {});
    const options = entry ? { onlyIfMatch: entry.etag } : { onlyIfNew: true };
    const written = await store.setJSON(key, draft, options);
    if (written.modified) return jsonResponse(outcome.status || 200, outcome.body || {});
  }
  return apiError(409, 'Another update happened at the same time. Please retry.');
}

function dayKey(date) {
  return `${DAY_PREFIX}${date}`;
}

function dayRecords(day, date) {
  return day.records.map((record) => ({
    ...record,
    reopenAllowed: day.reopenAllowed[recordKey(date, record.classKey)] === true,
  }));
}

function isAdmin(request, settings) {
  return pinMatches(request.headers.get('x-admin-pin'), settings.pins.admin);
}
function isPrincipal(request, settings) {
  return pinMatches(request.headers.get('x-principal-pin'), settings.pins.principal);
}
function isEither(request, settings) {
  return isAdmin(request, settings) || isPrincipal(request, settings);
}

function findArchivedTarget(classKey, currentRecord) {
  return {
    key: classKey,
    label: currentRecord.classLabel || DEFAULT_CLASS_BY_KEY.get(classKey)?.label || classKey,
    groupKey: currentRecord.groupKey || DEFAULT_CLASS_BY_KEY.get(classKey)?.groupKey || 'ARCHIVED',
    section: currentRecord.section || DEFAULT_CLASS_BY_KEY.get(classKey)?.section || '',
  };
}

export function createHandler(getStoreInstance = getStore) {
  return async function handleAttendanceApi(request) {
    try {
      const url = new URL(request.url);
      const route = url.pathname;
      const method = request.method.toUpperCase();
      const today = todayIST();
      const store = getStoreInstance(STORE_NAME);

      if (method === 'GET' && route === '/api/config') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        return jsonResponse(200, { today, groups: settings.groups, classes: classesFromGroups(settings.groups), session: publicSessionSettings(settings.session) });
      }

      if (method === 'GET' && route === '/api/records') {
        const date = url.searchParams.get('date') || today;
        if (!validDateForSchool(date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        const day = normalizeDay(await readJson(store, dayKey(date)));
        return jsonResponse(200, { date, records: dayRecords(day, date), classes: reportClasses(settings.groups, day.records), groups: settings.groups, session: publicSessionSettings(settings.session) });
      }

      if (method === 'GET' && route === '/api/previous') {
        const date = url.searchParams.get('date') || today;
        const classKey = url.searchParams.get('classKey') || '';
        if (!validDateForSchool(date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!classesFromGroups(settings.groups).some((item) => item.key === classKey)) return apiError(400, 'Choose a valid class and section.');
        const { blobs = [] } = await store.list({ prefix: DAY_PREFIX });
        const priorDates = blobs
          .map((blob) => blob.key.slice(DAY_PREFIX.length))
          .filter((candidate) => validDate(candidate) && candidate < date)
          .sort((a, b) => b.localeCompare(a));
        for (const priorDate of priorDates) {
          const day = normalizeDay(await readJson(store, dayKey(priorDate)));
          const record = day.records.filter((item) => item.classKey === classKey).sort((a, b) => b.date.localeCompare(a.date))[0];
          if (record) return jsonResponse(200, { date, classKey, record });
        }
        return jsonResponse(200, { date, classKey, record: null });
      }

      if (method === 'POST' && route === '/api/submit') {
        const body = await parseBody(request);
        if (!validDateForSchool(body.date, today)) return apiError(400, 'Choose a valid attendance date that is not in the future.');
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        const classItem = classesFromGroups(settings.groups).find((item) => item.key === body.classKey);
        if (!classItem) return apiError(400, 'Choose a valid class and section.');
        const counts = validateCounts(body);
        if (counts.error) return apiError(400, counts.error);
        return mutateJson(store, dayKey(body.date), emptyDay, normalizeDay, (day) => {
          const key = recordKey(body.date, body.classKey);
          const index = day.records.findIndex((item) => item.date === body.date && item.classKey === body.classKey);
          const existing = index >= 0 ? day.records[index] : null;
          if (existing && day.reopenAllowed[key] !== true) {
            return { persist: false, status: 409, body: { message: 'This class attendance has already been submitted. Ask the admin to allow one resubmission.', record: { ...existing, reopenAllowed: false } } };
          }
          const submittedAt = new Date().toISOString();
          const record = {
            id: randomUUID(), date: body.date, classKey: body.classKey,
            classLabel: classItem.label, groupKey: classItem.groupKey, section: classItem.section,
            ...counts, submittedAt, revision: existing ? (Number(existing.revision) || 1) + 1 : 1,
          };
          if (existing) {
            day.history.push({ action: 'resubmit', date: body.date, classKey: body.classKey, editedAt: submittedAt, oldRecord: existing, newRecord: record });
            day.records[index] = record;
            delete day.reopenAllowed[key];
          } else day.records.push(record);
          return { status: 201, body: { message: existing ? 'Attendance updated after admin approval.' : 'Attendance submitted.', replaced: Boolean(existing), record } };
        });
      }

      if (method === 'POST' && route === '/api/admin/verify') {
        const body = await parseBody(request);
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!pinMatches(body.pin, settings.pins.admin)) return apiError(401, 'Incorrect admin PIN.');
        return jsonResponse(200, { ok: true });
      }

      if (method === 'POST' && route === '/api/principal/verify') {
        const body = await parseBody(request);
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!pinMatches(body.pin, settings.pins.principal)) return apiError(401, 'Incorrect Principal PIN.');
        return jsonResponse(200, { ok: true });
      }

      if (method === 'GET' && route === '/api/admin/records') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isEither(request, settings)) return apiError(401, 'Admin or Principal access required.');
        const date = url.searchParams.get('date') || today;
        if (!validDateForSchool(date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        const day = normalizeDay(await readJson(store, dayKey(date)));
        const summary = url.searchParams.get('includeSession') === 'false' ? null : await readSessionSummary(store, settings, date);
        return jsonResponse(200, { date, records: dayRecords(day, date), history: day.history, classes: reportClasses(settings.groups, day.records), groups: settings.groups, sessionSettings: settings.session, sessionSummary: summary });
      }

      if (method === 'GET' && route === '/api/principal/records') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const date = url.searchParams.get('date') || today;
        if (!validDateForSchool(date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        const day = normalizeDay(await readJson(store, dayKey(date)));
        const summary = url.searchParams.get('includeSession') === 'false' ? null : await readSessionSummary(store, settings, date);
        return jsonResponse(200, { date, records: dayRecords(day, date), history: day.history, deletedRecords: day.deletedRecords, classes: reportClasses(settings.groups, day.records), groups: settings.groups, sessionSettings: settings.session, sessionSummary: summary });
      }

      if (method === 'POST' && route === '/api/admin/unlock') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isEither(request, settings)) return apiError(401, 'Admin or Principal access required.');
        const body = await parseBody(request);
        if (!validDateForSchool(body.date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        return mutateJson(store, dayKey(body.date), emptyDay, normalizeDay, (day) => {
          const exists = day.records.some((item) => item.date === body.date && item.classKey === body.classKey);
          if (!exists) return { persist: false, status: 404, body: { message: 'No submitted attendance found for this class and date.' } };
          day.reopenAllowed[recordKey(body.date, body.classKey)] = true;
          return { status: 200, body: { ok: true, alreadyAllowed: false, message: 'One resubmission is now allowed.' } };
        });
      }

      if (method === 'POST' && route === '/api/admin/change-pin') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isAdmin(request, settings)) return apiError(401, 'Admin access required.');
        const body = await parseBody(request);
        if (!validPin(body.newPin)) return apiError(400, 'PIN must contain 4–12 digits.');
        return mutateJson(store, SETTINGS_KEY, emptySettings, normalizeSettings, (updated) => {
          updated.pins.admin = body.newPin;
          return { status: 200, body: { ok: true, message: 'Admin PIN changed.' } };
        });
      }

      if (method === 'POST' && route === '/api/principal/change-pin') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const body = await parseBody(request);
        if (!validPin(body.newPin)) return apiError(400, 'PIN must contain 4–12 digits.');
        return mutateJson(store, SETTINGS_KEY, emptySettings, normalizeSettings, (updated) => {
          updated.pins.principal = body.newPin;
          return { status: 200, body: { ok: true, message: 'Principal PIN changed.' } };
        });
      }

      if (method === 'POST' && route === '/api/principal/admin-pin') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const body = await parseBody(request);
        if (!validPin(body.newPin)) return apiError(400, 'PIN must contain 4–12 digits.');
        return mutateJson(store, SETTINGS_KEY, emptySettings, normalizeSettings, (updated) => {
          updated.pins.admin = body.newPin;
          return { status: 200, body: { ok: true, message: 'Admin PIN changed by Principal.' } };
        });
      }

      if (method === 'POST' && route === '/api/admin/session-settings') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isEither(request, settings)) return apiError(401, 'Admin or Principal access required.');
        const body = await parseBody(request);
        if (!validDateForSchool(body.startDate, today)) return apiError(400, 'Choose a valid session start date that is not in the future.');
        const rawOpening = body.openingByClass && typeof body.openingByClass === 'object' && !Array.isArray(body.openingByClass) ? body.openingByClass : null;
        if (!rawOpening || Object.keys(rawOpening).length > 200) return apiError(400, 'Opening balances must be a class-by-class object.');
        for (const [classKey, counts] of Object.entries(rawOpening)) {
          if (!/^[A-Z0-9]{1,12}$/i.test(classKey) || !counts || typeof counts !== 'object' || (!((counts.startingTotal == null || counts.startingTotal === '') || (Number.isInteger(Number(counts.startingTotal)) && Number(counts.startingTotal) >= 0 && Number(counts.startingTotal) <= 500)) || ['admission', 'withdrawal', 'dormant'].some((field) => !Number.isInteger(Number(counts[field] ?? 0)) || Number(counts[field] ?? 0) < 0 || Number(counts[field] ?? 0) > 1000000))) {
            return apiError(400, 'Opening movement counts must be whole numbers between 0 and 1,000,000.');
          }
        }
        return mutateJson(store, SETTINGS_KEY, emptySettings, normalizeSettings, (updated) => {
          updated.session = normalizeSessionSettings({ startDate: body.startDate, openingByClass: rawOpening });
          return { status: 200, body: { ok: true, message: 'Session settings and opening balances saved.', session: updated.session } };
        });
      }

      if (method === 'POST' && route === '/api/admin/classes') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isEither(request, settings)) return apiError(401, 'Admin or Principal access required.');
        const body = await parseBody(request);
        const groups = normalizeGroups(body.groups);
        if (!groups) return apiError(400, 'Class list is invalid. Check class keys, names, and section codes.');
        return mutateJson(store, SETTINGS_KEY, emptySettings, normalizeSettings, (updated) => {
          updated.groups = groups;
          return { status: 200, body: { ok: true, message: 'Classes and sections updated.', groups, classes: classesFromGroups(groups) } };
        });
      }

      if (method === 'POST' && route === '/api/principal/update-record') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const body = await parseBody(request);
        const { date, classKey, newClassKey } = body;
        if (!validDateForSchool(date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        return mutateJson(store, dayKey(date), emptyDay, normalizeDay, (day) => {
          const index = day.records.findIndex((item) => item.date === date && item.classKey === classKey);
          if (index < 0) return { persist: false, status: 404, body: { message: 'Active attendance record not found.' } };
          const targetKey = newClassKey || classKey;
          const currentRecord = day.records[index];
          const activeTarget = classesFromGroups(settings.groups).find((item) => item.key === targetKey);
          const targetClass = activeTarget || (targetKey === classKey ? findArchivedTarget(classKey, currentRecord) : null);
          if (!targetClass) return { persist: false, status: 400, body: { message: 'Choose an active class and section.' } };
          const duplicate = day.records.some((item, itemIndex) => itemIndex !== index && item.date === date && item.classKey === targetKey);
          if (duplicate) return { persist: false, status: 409, body: { message: 'That class already has an attendance record for this date.' } };
          const counts = validateCounts(body);
          if (counts.error) return { persist: false, status: 400, body: { message: counts.error } };
          const previous = day.records[index];
          const editedAt = new Date().toISOString();
          const updatedRecord = {
            ...previous, classKey: targetKey, classLabel: targetClass.label, groupKey: targetClass.groupKey, section: targetClass.section,
            ...counts, updatedAt: editedAt, revision: (Number(previous.revision) || 1) + 1,
          };
          day.history.push({ action: 'edit', date, classKey: previous.classKey, newClassKey: targetKey, editedAt, oldRecord: previous, newRecord: updatedRecord });
          day.records[index] = updatedRecord;
          delete day.reopenAllowed[recordKey(date, classKey)];
          delete day.reopenAllowed[recordKey(date, targetKey)];
          return { status: 200, body: { ok: true, message: 'Attendance record updated.', record: updatedRecord } };
        });
      }

      if (method === 'POST' && route === '/api/principal/delete-record') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const body = await parseBody(request);
        if (!validDateForSchool(body.date, today)) return apiError(400, 'Choose a valid date that is not in the future.');
        return mutateJson(store, dayKey(body.date), emptyDay, normalizeDay, (day) => {
          const index = day.records.findIndex((item) => item.date === body.date && item.classKey === body.classKey);
          if (index < 0) return { persist: false, status: 404, body: { message: 'Active attendance record not found.' } };
          const oldRecord = day.records[index];
          const deletedAt = new Date().toISOString();
          const deleted = { id: randomUUID(), date: oldRecord.date, classKey: oldRecord.classKey, deletedAt, oldRecord };
          day.records.splice(index, 1);
          day.deletedRecords.push(deleted);
          day.history.push({ action: 'delete', date: oldRecord.date, classKey: oldRecord.classKey, editedAt: deletedAt, oldRecord });
          delete day.reopenAllowed[recordKey(oldRecord.date, oldRecord.classKey)];
          return { status: 200, body: { ok: true, message: 'Record moved to Principal trash (recoverable).', deleted } };
        });
      }

      if (method === 'POST' && route === '/api/principal/restore-record') {
        const settings = normalizeSettings(await readJson(store, SETTINGS_KEY));
        if (!isPrincipal(request, settings)) return apiError(401, 'Principal access required.');
        const body = await parseBody(request);
        if (!validDateForSchool(body.date, today)) return apiError(400, 'Choose the date of the deleted record.');
        return mutateJson(store, dayKey(body.date), emptyDay, normalizeDay, (day) => {
          const index = day.deletedRecords.findIndex((item) => item.id === body.deletedId);
          if (index < 0) return { persist: false, status: 404, body: { message: 'Deleted record not found.' } };
          const deleted = day.deletedRecords[index];
          const oldRecord = deleted.oldRecord;
          if (day.records.some((item) => item.date === oldRecord.date && item.classKey === oldRecord.classKey)) {
            return { persist: false, status: 409, body: { message: 'A record already exists for this class/date; restore is blocked to prevent duplicates.' } };
          }
          day.records.push(oldRecord);
          day.deletedRecords.splice(index, 1);
          day.history.push({ action: 'restore', date: oldRecord.date, classKey: oldRecord.classKey, editedAt: new Date().toISOString(), oldRecord });
          return { status: 200, body: { ok: true, message: 'Record restored.' } };
        });
      }

      if (route.startsWith('/api/')) return apiError(404, 'API route not found.');
      return apiError(404, 'Not found.');
    } catch (error) {
      if (Number.isInteger(error?.status)) return apiError(error.status, error.message);
      console.error('Attendance API error:', error);
      return apiError(500, 'Shared attendance service is temporarily unavailable. Please retry.');
    }
  };
}

export default createHandler();

export const config = {
  path: '/api/*',
};
